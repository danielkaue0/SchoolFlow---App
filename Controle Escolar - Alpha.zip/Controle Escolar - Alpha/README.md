# 🎓 Controle Escolar

Sistema de organização de tarefas e produtividade para estudantes.

![Versão](https://img.shields.io/badge/version-1.0.0--Alpha-blue)
![Python](https://img.shields.io/badge/python-3.14-green)
![Tkinter](https://img.shields.io/badge/Tkinter-GUI-orange)
![SQLite](https://img.shields.io/badge/SQLite-Database-lightgrey)

---

## 📋 Sobre o Projeto

O **Controle Escolar** é um aplicativo desktop desenvolvido para ajudar estudantes a organizar suas tarefas, gerenciar matérias e aumentar a produtividade com o método Pomodoro.

### ✨ Funcionalidades

| Funcionalidade | Descrição |
|----------------|-----------|
| 📋 **Tarefas** | CRUD completo (criar, editar, excluir, concluir) |
| 📁 **Matérias** | Gerenciamento de disciplinas |
| 🍅 **Pomodoro** | Timer com modos 25/5, 25/10, 25/15 |
| ⚙️ **Configurações** | Tema claro/escuro e resolução de tela |
| 💾 **Banco de Dados** | SQLite local (offline) |

---

## 🚀 Como Executar

### Opção 1: Executável (.exe)
1. Baixe o arquivo `ControleEscolar.exe`
2. Execute-o diretamente (não precisa instalar nada)
3. O banco de dados será criado automaticamente na pasta `data/`

### Opção 2: Código fonte
```bash
# Clone o repositório
git clone https://github.com/seu-usuario/controle-escolar.git

# Entre na pasta
cd controle-escolar

# Execute
python main.py

==========================================================================================
Python 3.14 - Linguagem de programação

Tkinter - Interface gráfica (nativa)

SQLite3 - Banco de dados local

PyInstaller - Geração do executável
==========================================================================================
📦 Requisitos Mínimos
SO: Windows 7 ou superior

RAM: 512 MB

Armazenamento: 50 MB livres

Python: Não necessário (no executável)
==========================================================================================
🐛 Reportar Bugs
Caso encontre algum bug, por favor, abra uma issue no repositório ou entre em contato:

Email: controleescolarapp@gmail.com

GitHub: github.com/danielkaue0
==========================================================================================
📄 Licença
Este projeto está sob a licença MIT. Veja o arquivo LICENSE para mais detalhes.
==========================================================================================
👥 Equipe
Desenvolvimento: Equipe Dev

Versão Alpha: 1.0.0
==========================================================================================
🙏 Agradecimentos
Python comunidade

Tkinter

SQLite