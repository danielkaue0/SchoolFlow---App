# 📋 Changelog - Controle Escolar

Todas as mudanças notáveis neste projeto serão documentadas neste arquivo.

O formato é baseado em [Keep a Changelog](https://keepachangelog.com/pt-BR/1.0.0/),
e este projeto adere ao [Versionamento Semântico](https://semver.org/lang/pt-BR/).

---

## [1.0.0] - Alpha - 2026-04-04

### ✨ Adicionado

#### 🎯 Sistema de Tarefas (CRUD Completo)
- Criar tarefas com nome, matéria e prazo
- Listar tarefas com filtros (todas, pendentes, concluídas, atrasadas)
- Editar tarefas existentes
- Excluir tarefas
- Concluir/Reabrir tarefas
- Cards coloridos por status:
  - 🟢 Verde: Concluída
  - 🔴 Vermelho: Atrasada
  - 🟠 Laranja: Vence hoje
  - ⚪ Branco: Normal

#### 📚 Sistema de Matérias
- Criar matérias
- Listar matérias com contagem de tarefas
- Excluir matérias (com remoção em cascata das tarefas)
- Matéria padrão "Geral" criada automaticamente
- Card com estatísticas (total, concluídas, pendentes)

#### 🍅 Pomodoro Timer
- Timer funcional com modos:
  - 25/5 (25 min foco / 5 min descanso)
  - 25/10 (25 min foco / 10 min descanso)
  - 25/15 (25 min foco / 15 min descanso)
- Controles: Iniciar, Pausar, Resetar
- Alternância automática entre foco e descanso
- Barra de progresso visual
- Thread separada para o timer (não trava a interface)
- Formato MM:SS

#### ⚙️ Configurações
- Tema claro/escuro (aplicação global)
- Resoluções disponíveis:
  - 800x600 (Pequena)
  - 900x700 (Padrão)
  - 1024x768 (Média)
  - 1280x720 (Grande)
- Informações do aplicativo (versão, autor)

#### 💾 Banco de Dados (SQLite)
- Estrutura local offline
- Tabelas: `materias`, `tarefas`
- Índices para performance
- Foreign key com CASCADE
- Singleton pattern para conexão
- Dado inicial (Matéria "Geral")

#### 🎨 Interface Gráfica (Tkinter)
- Navegação entre telas (Router pattern)
- Scroll em listas longas
- Cards responsivos
- Botões com hover
- Diálogos modais para formulários
- Confirmação ao sair
- Mouse wheel suporte

#### 🧩 Componentes Reutilizáveis
- Botões (primário, secundário, perigo, sucesso)
- Inputs (texto, senha, data, busca)
- Lista de tarefas rolável
- Item de tarefa individual
- Timer widget

#### 🛠️ Utilitários
- Validações (nome, data, número)
- Formatação (tempo, data, atraso)
- Configurações centralizadas
- Resoluções responsivas

### 🐛 Corrigido

N/A (versão inicial)

### ⚠️ Conhecido

Nenhum bug crítico identificado na versão Alpha

---

## [Próximas Versões]

### 🔜 Beta 1.1.0 - Planejado (Maio/2026)

#### Novas Funcionalidades
- [ ] Notificações de tarefas pendentes
- [ ] Lembretes de tarefas próximas do prazo
- [ ] Relatórios de produtividade
- [ ] Gráficos de conclusão de tarefas (Matplotlib)
- [ ] Backup e restauração do banco de dados
- [ ] Exportar tarefas para CSV/PDF
- [ ] Pesquisa avançada de tarefas
- [ ] Categorias e etiquetas
- [ ] Prioridades (alta, média, baixa)
- [ ] Data de conclusão registrada

#### Melhorias
- [ ] Animações e transições
- [ ] Atalhos de teclado (Ctrl+N, Ctrl+S, etc.)
- [ ] Modo foco (tela cheia)
- [ ] Melhor responsividade
- [ ] Loading indicators

#### Correções
- [ ] Ajustes de performance
- [ ] Correção de bugs reportados

---

### 🔜 Beta 1.2.0 - Planejado (Julho/2026)

- [ ] Calendário mensal de tarefas
- [ ] Meta de estudos diária
- [ ] Ranking de produtividade
- [ ] Tempo gasto por tarefa
- [ ] Gráficos semanais/mensais
- [ ] Relatórios exportáveis
- [ ] Tema personalizável (cores)
- [ ] Fontes personalizadas

---

### 🔜 Estável 2.0.0 - Planejado (Setembro/2026)

- [ ] Sincronização com nuvem (opcional)
- [ ] Múltiplos usuários
- [ ] Modo offline/online
- [ ] API para integrações
- [ ] Aplicativo mobile (React Native)
- [ ] Integração com Google Calendar
- [ ] IA para recomendações de estudo
- [ ] Gamificação (níveis, conquistas)

---

## 📊 Roadmap Visual
